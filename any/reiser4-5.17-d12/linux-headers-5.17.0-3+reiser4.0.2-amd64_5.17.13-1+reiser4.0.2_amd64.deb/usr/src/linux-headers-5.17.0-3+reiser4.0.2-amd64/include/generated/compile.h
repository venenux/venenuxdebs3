/* This file is auto generated, version 1 */
/* SMP PREEMPT */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#1 SMP PREEMPT Debian 5.17.13-1+reiser4.0.2 (2024-10-26)"
#define LINUX_COMPILE_BY "debian-kernel"
#define LINUX_COMPILE_HOST "lists.debian.org"
#define LINUX_COMPILER "gcc-12 (Debian 12.2.0-14) 12.2.0, GNU ld (GNU Binutils for Debian) 2.40"
