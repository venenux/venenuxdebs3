#define UTS_RELEASE "5.17.0-3+reiser4.0.2-cloud-amd64"
